<!-- 
	// Front end layout
	// for our Playlists frontend grid 
	// @since v2.0
	to do 
-->